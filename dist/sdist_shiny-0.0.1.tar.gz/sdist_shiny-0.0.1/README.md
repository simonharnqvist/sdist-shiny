## Sdist-Shiny

A web app for visualising the expected segregating sites distribution

### Install
